# Experiment 4: Energy Consumption
import os, pandas as pd, matplotlib.pyplot as plt
root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
df = pd.read_csv(os.path.join(root,"datasets","exp4_energy.csv"))
avg = df.mean()
plt.figure(figsize=(6,4)); avg.plot(kind='bar'); plt.ylabel("Energy (W)"); plt.title("Exp4: Avg Energy by Mode"); plt.tight_layout()
plt.savefig(os.path.join(root,"datasets","exp4_energy_bar.png"), dpi=300); plt.close()
print("Exp4 complete.")