# Experiment 5: AI Alerting Accuracy
import os, pandas as pd
from sklearn.metrics import confusion_matrix, classification_report, roc_curve, auc
import matplotlib.pyplot as plt
root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
df = pd.read_csv(os.path.join(root,"datasets","exp5_alerts.csv"))
y_true = df['true_label']; y_pred = df['predicted_label']; y_prob = df['probability']
print("Classification report:\n", classification_report(y_true,y_pred))
cm = confusion_matrix(y_true,y_pred)
plt.figure(figsize=(5,5)); plt.imshow(cm, cmap='Blues'); plt.title("Confusion Matrix"); plt.colorbar()
plt.savefig(os.path.join(root,"datasets","exp5_confusion_matrix.png"), dpi=300); plt.close()
fpr,tpr, _ = roc_curve(y_true, y_prob); roc_auc = auc(fpr,tpr)
plt.figure(); plt.plot(fpr,tpr,label='AUC={:.2f}'.format(roc_auc)); plt.plot([0,1],[0,1],'k--')
plt.xlabel('FPR'); plt.ylabel('TPR'); plt.title('ROC Curve'); plt.legend(); plt.savefig(os.path.join(root,'datasets','exp5_roc.png'), dpi=300); plt.close()
print('Exp5 complete.')