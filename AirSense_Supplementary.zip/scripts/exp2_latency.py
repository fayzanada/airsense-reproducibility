# Experiment 2: Data Transmission Latency
import os, pandas as pd, matplotlib.pyplot as plt
root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
df = pd.read_csv(os.path.join(root,"datasets","exp2_latency.csv"))
wifi = df["WiFi_Latency_s"]; gsm = df["GSM_Latency_s"]
plt.figure(figsize=(7,4)); plt.hist(wifi, bins=30, alpha=0.7, label="WiFi"); plt.hist(gsm, bins=30, alpha=0.7, label="GSM")
plt.xlabel("Latency (s)"); plt.ylabel("Count"); plt.title("Exp2: Latency Distribution"); plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(root,"datasets","exp2_latency_hist.png"), dpi=300); plt.close()
print("Exp2 complete.")