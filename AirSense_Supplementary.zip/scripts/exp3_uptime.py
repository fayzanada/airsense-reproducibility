# Experiment 3: Uptime and Reliability
import os, pandas as pd, matplotlib.pyplot as plt
root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
df = pd.read_csv(os.path.join(root,"datasets","exp3_uptime.csv"))
avg = df.mean()
plt.figure(figsize=(6,4))
avg.plot(kind='bar'); plt.ylabel("Uptime (%)"); plt.title("Exp3: Average Uptime by Mode"); plt.tight_layout()
plt.savefig(os.path.join(root,"datasets","exp3_uptime_bar.png"), dpi=300); plt.close()
print("Exp3 complete.")