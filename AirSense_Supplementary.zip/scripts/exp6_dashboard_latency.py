# Experiment 6: Dashboard/UI Latency Analysis
import os, pandas as pd, matplotlib.pyplot as plt
root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
df = pd.read_csv(os.path.join(root,"datasets","exp6_dashboard_latency.csv"))
plt.figure(figsize=(7,4)); plt.hist(df['ui_latency_s'], bins=30); plt.xlabel('UI Latency (s)'); plt.ylabel('Count')
plt.title('Exp6: Dashboard/UI Latency Distribution'); plt.tight_layout(); plt.savefig(os.path.join(root,'datasets','exp6_ui_latency_hist.png'), dpi=300); plt.close()
plt.figure(figsize=(6,4)); df['ui_latency_s'].plot(kind='box'); plt.title('Exp6: UI Latency Boxplot'); plt.tight_layout(); plt.savefig(os.path.join(root,'datasets','exp6_ui_latency_box.png'), dpi=300); plt.close()
print('Exp6 complete.')