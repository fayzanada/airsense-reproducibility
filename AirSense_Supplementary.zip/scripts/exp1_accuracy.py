# Experiment 1: Sensor Accuracy Validation
import os, pandas as pd, matplotlib.pyplot as plt
root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
df = pd.read_csv(os.path.join(root,"datasets","exp1_accuracy.csv"))
t = df["Time_min"]
plt.figure(figsize=(8,4))
plt.plot(t, df["Reference_PM25"], label="Reference")
plt.plot(t, df["AirSense_PM25"], label="AirSense", linestyle="--")
plt.xlabel("Time (min)"); plt.ylabel("PM2.5 (ug/m3)")
plt.title("Exp1: PM2.5 Time Series"); plt.legend(); plt.tight_layout()
plt.savefig(os.path.join(root,"datasets","exp1_timeseries.png"), dpi=300); plt.close()
print("Exp1 script finished.")