AirSense Supplementary Reproducibility Package
=============================================

Contents:
- scripts/: Python scripts to reproduce plots and analyses
  - exp1_accuracy.py
  - exp2_latency.py
  - exp3_uptime.py
  - exp4_energy.py
  - exp5_alerts.py
  - exp6_dashboard_latency.py
- datasets/: CSV files used by the scripts (synthetic example data)
  - exp1_accuracy.csv
  - exp2_latency.csv
  - exp3_uptime.csv
  - exp4_energy.csv
  - exp5_alerts.csv
  - exp6_dashboard_latency.csv

How to use:
1. Install dependencies: pip install -r requirements.txt
2. From the package root, run scripts in the scripts/ folder. Figures will be saved into datasets/ for convenience.
   e.g. python scripts/exp1_accuracy.py

Notes:
- The datasets included are synthetic examples matching the formats used in the manuscript.
- Replace datasets/*.csv with real experiment data if available to reproduce exact paper figures.
- License: MIT. Cite the paper when using these materials.
